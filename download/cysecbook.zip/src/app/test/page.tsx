export default function TestPage() {
  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Testing Suite</h1>
        
        <div className="grid gap-6 md:grid-cols-2">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">SQL Injection Tests</h2>
            <form action="/api/test/sqli" method="GET" className="space-y-4">
              <input
                name="id"
                placeholder="User ID (try: 1 OR 1=1)"
                className="w-full p-2 border rounded"
              />
              <button type="submit" className="w-full p-2 bg-blue-600 text-white rounded">
                Test SQL Injection
              </button>
            </form>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">XSS Tests</h2>
            <form action="/api/test/xss" method="POST" className="space-y-4">
              <textarea
                name="content"
                placeholder="Enter content (try: <script>alert('XSS')</script>)"
                className="w-full p-2 border rounded h-24"
              />
              <button type="submit" className="w-full p-2 bg-blue-600 text-white rounded">
                Test XSS
              </button>
            </form>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">File Upload Test</h2>
            <form action="/api/test/upload" method="POST" encType="multipart/form-data" className="space-y-4">
              <input
                type="file"
                name="file"
                className="w-full p-2 border rounded"
              />
              <button type="submit" className="w-full p-2 bg-blue-600 text-white rounded">
                Upload File
              </button>
            </form>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Command Injection Test</h2>
            <form action="/api/test/cmd" method="POST" className="space-y-4">
              <input
                name="host"
                placeholder="Hostname (try: ; cat /etc/passwd)"
                className="w-full p-2 border rounded"
              />
              <button type="submit" className="w-full p-2 bg-blue-600 text-white rounded">
                Ping Host
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
